function validateSignup() {
    let name = document.getElementsByName("name")[0].value.trim();
    let email = document.getElementsByName("email")[0].value.trim();
    let username = document.getElementsByName("username")[0].value.trim();
    let pass = document.getElementById("password").value;
    let confirm = document.getElementById("confirm").value;

    if (name === "" || email === "" || username === "" || pass === "" || confirm === "") {
        alert("All fields are required");
        return false;
    }

    let emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!email.match(emailPattern)) {
        alert("Invalid email");
        return false;
    }

    if (pass.length < 6) {
        alert("Password must be at least 6 characters");
        return false;
    }

    if (pass !== confirm) {
        alert("Passwords do not match");
        return false;
    }

    // Save to localStorage
    localStorage.setItem("username", username);
    localStorage.setItem("password", pass);

    alert("Signup successful!");
    window.location.href = "login.html"; // redirect to login
    return false;
}

function validateLogin() {
    let user = document.getElementsByName("user")[0].value.trim();
    let pass = document.getElementsByName("password")[0].value;

    if (user === "" || pass === "") {
        alert("All fields required");
        return false;
    }

    let storedUser = localStorage.getItem("username");
    let storedPass = localStorage.getItem("password");

    if (user === storedUser && pass === storedPass) {
        alert("Login successful!");
        return true;
    } else {
        alert("Invalid username or password");
        return false;
    }
}