<?xml version="1.0"?>

<xsl:stylesheet version="1.0"
xmlns:xsl="http://www.w3.org/1999/XSL/Transform">

<xsl:template match="/">

<html>
<body>

<h2>All Student Results</h2>

<table border="1" cellpadding="8" cellspacing="0">
<tr style="background-color:lightgray;">
    <th>Name</th>
    <th>Class</th>
    <th>Roll No</th>
    <th>Marks</th>
    <th>Result</th>
</tr>

<xsl:for-each select="students/student">
<tr>
    <td><xsl:value-of select="name"/></td>
    <td><xsl:value-of select="class"/></td>
    <td><xsl:value-of select="roll"/></td>
    <td><xsl:value-of select="marks"/></td>

    <td>
        <xsl:choose>
            <xsl:when test="marks &lt; 40">
                <span style="color:red;">Fail</span>
            </xsl:when>
            <xsl:otherwise>
                <span style="color:green;">Pass</span>
            </xsl:otherwise>
        </xsl:choose>
    </td>

</tr>
</xsl:for-each>

</table>

</body>
</html>

</xsl:template>

</xsl:stylesheet>