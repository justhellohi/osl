function validateForm() {
    let name = document.getElementById("name").value.trim();
    let email = document.getElementById("email").value.trim();
    let age = document.getElementById("age").value.trim();
    let rollNo = document.getElementById("rollNo").value.trim();
    let photo = document.getElementById("photo").files;

    
    if (name === "") {
        alert("Name is required");
        return false;
    }

    
    let emailPattern = /^[^ ]+@[^ ]+\.[a-z]{2,3}$/;
    if (email === "") {
        alert("Email is required");
        return false;
    }
    if (!email.match(emailPattern)) {
        alert("Enter a valid email");
        return false;
    }


    if (age === "") {
        alert("Age is required");
        return false;
    }
    if (age < 16 || age > 100) {
        alert("Age must be between 16 and 100");
        return false;
    }

    
    let rollPattern = /^STU\d{3}$/;
    if (rollNo === "") {
        alert("Roll Number is required");
        return false;
    }
    if (!rollNo.match(rollPattern)) {
        alert("Roll Number must be in format STU123");
        return false;
    }


    if (photo.length === 0) {
        alert("Please upload a profile photo");
        return false;
    }

    alert("Form submitted successfully!");
    return true;
}