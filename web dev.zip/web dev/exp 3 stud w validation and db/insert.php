<?php
include "db.php";

$name = $_POST['name'];
$email = $_POST['email'];
$mobile = $_POST['mobile'];
$course = $_POST['course'];

$sql = "INSERT INTO students (name, email, mobile, course)
VALUES ('$name', '$email', '$mobile', '$course')";

if (mysqli_query($conn, $sql)) {
    echo "Record Inserted Successfully<br>";
    echo "<a href='index.html'>Go Back</a>";
} else {
    echo "Error";
}
?>