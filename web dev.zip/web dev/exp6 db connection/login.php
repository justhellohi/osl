<?php
include "db.php";

$user = $_POST['user'];
$pass = $_POST['password'];

$sql = "SELECT * FROM users 
WHERE (username='$user' OR email='$user') AND password='$pass'";

$result = mysqli_query($conn, $sql);

if (mysqli_num_rows($result) > 0) {
    echo "Welcome! Login successful";
} else {
    echo "Invalid credentials";
}
?>