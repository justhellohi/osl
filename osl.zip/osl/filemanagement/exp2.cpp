#include <iostream>
#include <fcntl.h>
#include <unistd.h>

using namespace std;

int main()
{
    int fd;

    // Open file in read mode
    fd = open("student.txt", O_RDONLY);

    if (fd == -1)
    {
        cout << "File cannot open" << endl;
        return 1;
    }

    cout << "File opened successfully" << endl;

    // Close file
    close(fd);

    cout << "File closed successfully" << endl;

    return 0;
}
