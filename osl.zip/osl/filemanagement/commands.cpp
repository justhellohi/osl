// List all files and directories in the current folder
//file management

ls

// Print the working directory (shows the full path of where you are)
pwd

// Create an empty file named file1.txt
touch file1.txt

// Display the contents of file1.txt (currently empty)
cat file1.txt

// Attempted to copy file1.txt but failed due to a missing space/operand
cp file1.txtfile2.txt 

// Copy file1.txt to a new file named file2.txt
cp file1.txt file2.txt

// Rename (move) file1.txt to a new name: newfile.txt
mv file1.txt newfile.txt

// Attempted to remove file1.txt but failed because it was renamed to newfile.txt
rm file1.txt

// Remove (delete) the file file1.txt (Note: this would work if the file existed)
rm file1.txt

//directory manasge
// Make a new directory (folder) named oslab
mkdir oslab

// Remove the empty directory named oslab
rmdir oslab

// Attempted to enter the oslab directory but failed because it was just deleted
cd oslab

// Create the oslab directory again
mkdir oslab

// Change directory to enter the oslab folder
cd oslab

// Print the current working directory to confirm the new path
pwd

// Attempted to run 'tree' (likely a typo as 'tcd-ree') to show folder structure
tcd-ree

// Another typo for the 'tree' command
tcd -ree

//process mang
//ps -e
//top
//kill
//sleep 5
