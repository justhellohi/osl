#include <iostream>
#include <fcntl.h>    // For open(), creat()
#include <unistd.h>   // For read(), write(), close()
#include <cstring>    // For strlen()

using namespace std;

void fileManagement() {
    cout << "\n===== FILE MANAGEMENT =====\n";
    int fd; // File descriptor

    // Create File
    fd = creat("file_demo.txt", 0777);
    if (fd < 0) {
        cout << "File creation failed!\n";
        return;
    }
    cout << "File created successfully.\n";

    // Write Into File
    const char *data = "Hello Linux System Calls!";
    write(fd, data, strlen(data));
    cout << "Data written successfully.\n";
    close(fd); // Close after writing

    // Open File (Read Mode)
    fd = open("file_demo.txt", O_RDONLY);
    char buffer[100];
    int bytes = read(fd, buffer, sizeof(buffer));
    buffer[bytes] = '\0';
    cout << "Data read from file: " << buffer << endl;
    close(fd);

    // Delete File
    unlink("file_demo.txt");
    cout << "File deleted successfully.\n";
}

int main() {
    fileManagement();
    return 0;
}
