#include <iostream>
#include <sys/stat.h>  // stat(), chmod()
#include <ctime>       // Time functions

using namespace std;

int main()
{
    struct stat fileInfo;

    // ----------------------------
    // GET FILE ATTRIBUTES
    // ----------------------------
    if (stat("info.txt", &fileInfo) == 0)
    {
        cout << "File Size: " << fileInfo.st_size << " bytes" << endl;
        cout << "Last Modified: " << ctime(&fileInfo.st_mtime);
        cout << "Permissions: " << fileInfo.st_mode << endl;
    }
    else
    {
        cout << "Cannot get file info" << endl;
        return 1;
    }

    // ----------------------------
    // SET FILE ATTRIBUTES
    // ----------------------------
    // Change permission to rw-r--r--
    chmod("info.txt", 0644);

    cout << "File permission changed" << endl;

    return 0;
}
