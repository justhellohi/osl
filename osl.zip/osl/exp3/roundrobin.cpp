#include <iostream>
using namespace std;

int main()
{
    int n, tq;
    cout << "Enter number of processes: ";
    cin >> n;
    int at[n], bt[n], rt[n], ct[n], tat[n], wt[n];

    // Input Arrival Time and Burst Time
    for(int i = 0; i < n; i++)
    {
        cout << "Enter Arrival Time and Burst Time for P" << i+1 << ": ";
        cin >> at[i] >> bt[i];
        rt[i] = bt[i]; // Remaining time initially equals burst time
    }

    cout << "Enter Time Quantum: ";
    cin >> tq;

    int time = 0;
    int completed = 0;
    cout << "\nGantt Chart:\n";
    cout << time;

    while(completed < n) {
        bool executed = false;
        for(int i = 0; i < n; i++)
        {
            if(at[i] <= time && rt[i] > 0)
            {
                executed = true;
                cout << " | P" << i+1;
                if(rt[i] > tq)
                {
                    time += tq;
                    rt[i] -= tq;
                }
                else
                {
                    time += rt[i];
                    rt[i] = 0;
                    completed++;
                    ct[i] = time;
                    tat[i] = ct[i] - at[i];
                    wt[i] = tat[i] - bt[i];
                }
                cout << " " << time;
            }
        }
        if(!executed)
        {
            time++; // CPU Idle
        }
    }

    cout << "\n\nPID\tAT\tBT\tCT\tTAT\tWT\n";
    for(int i = 0; i < n; i++)
    {
        cout << "P" << i+1 << "\t"
             << at[i] << "\t"
             << bt[i] << "\t"
             << ct[i] << "\t"
             << tat[i] << "\t"
             << wt[i] << endl;
    }
    return 0;
}