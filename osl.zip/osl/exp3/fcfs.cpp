#include <iostream>    // Include input-output library
#include <algorithm>   // Include algorithm library for sorting
using namespace std;   // Use standard namespace

// Structure to store process details
struct Process
{
    int pid;    // Process ID
    int at;     // Arrival Time
    int bt;     // Burst Time
    int ct;     // Completion Time
    int tat;    // Turnaround Time
    int wt;     // Waiting Time
};

int main()
{
    int n;    // Variable to store number of processes
    cout << "Enter number of processes: ";
    cin >> n; // Read number of processes
    Process p[n]; // Create array of structure for n processes

    // ----- INPUT SECTION -----
    for(int i = 0; i < n; i++)
    {
        p[i].pid = i + 1;
        cout << "Enter Arrival Time and Burst Time for P" << i+1 << ": ";
        cin >> p[i].at >> p[i].bt; // Take arrival and burst time
    }

    // ----- SORT PROCESSES BY ARRIVAL TIME -----
    sort(p, p + n, [](Process a, Process b)
    {
        return a.at < b.at; // Sort in ascending order of arrival time
    });

    int time = 0; // Current CPU time starts from 0
    // ----- CALCULATE COMPLETION TIME -----
    for(int i = 0; i < n; i++)
    {
        // If CPU is idle (process arrives after current time)
        if(time < p[i].at) {
            time = p[i].at; // Move time forward to arrival time
        }
        time = time + p[i].bt;      // Execute process fully
        p[i].ct = time;             // Store completion time
        p[i].tat = p[i].ct - p[i].at; // Turnaround Time = CT - AT
        p[i].wt = p[i].tat - p[i].bt; // Waiting Time = TAT - BT
    }

    // ----- OUTPUT SECTION -----
    cout << "\nPID\tAT\tBT\tCT\tTAT\tWT\n";
    for(int i = 0; i < n; i++)
    {
        cout << p[i].pid << "\t"
             << p[i].at << "\t"
             << p[i].bt << "\t"
             << p[i].ct << "\t"
             << p[i].tat << "\t"
             << p[i].wt << "\n";
    }
    return 0;
}