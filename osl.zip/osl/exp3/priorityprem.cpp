#include <iostream>
using namespace std;

int main() {
    int n; // Number of processes
    cout << "Enter number of processes: ";
    cin >> n;

    int at[n];  // Arrival Time
    int bt[n];  // Burst Time
    int pr[n];  // Priority
    int rt[n];  // Remaining Time
    int ct[n];  // Completion Time
    int tat[n]; // Turnaround Time
    int wt[n];  // Waiting Time

    // Input process details
    for (int i = 0; i < n; i++) {
        cout << "Enter Arrival Time, Burst Time and Priority for P" << i + 1 << ": ";
        cin >> at[i] >> bt[i] >> pr[i];
        rt[i] = bt[i]; // Initially remaining time = burst time
    }

    int time = 0; // Current time
    int completed = 0; // Number of completed processes

    // Run until all processes are completed
    while (completed < n) {
        int index = -1; // To store selected process index
        int highest_priority = 9999; // Assume very large priority initially

        for (int i = 0; i < n; i++) {
            if (at[i] <= time && rt[i] > 0) {
                // Smaller number means higher priority
                if (pr[i] < highest_priority) {
                    highest_priority = pr[i]; // Update highest priority
                    index = i;
                }
            }
        }

        // If a process is found
        if (index != -1) {
            rt[index]--; // Execute process for 1 unit of time
            time++;      // Increase current time

            // If process finished
            if (rt[index] == 0) {
                completed++; // Increase completed count
                ct[index] = time; // Store completion time
                tat[index] = ct[index] - at[index]; // Turnaround Time
                wt[index] = tat[index] - bt[index];
            }
        } else {
            time++;
        }
    }

    cout << "\nPID\tAT\tBT\tPRI\tCT\tTAT\tWT\n";
    for (int i = 0; i < n; i++) {
        cout << "P" << i + 1 << "\t"
             << at[i] << "\t"
             << bt[i] << "\t"
             << pr[i] << "\t"
             << ct[i] << "\t"
             << tat[i] << "\t"
             << wt[i] << endl;
    }

    return 0;
}