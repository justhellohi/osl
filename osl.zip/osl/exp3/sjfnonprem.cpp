#include <iostream>
using namespace std;

int main()
{
    int n;
    cout << "Enter number of processes: "; // Ask user for number of processes
    cin >> n;                              // Read number of processes

    // Declare arrays to store process data
    int at[n];        // Arrival Time array
    int bt[n];        // Burst Time array
    int ct[n];        // Completion Time array
    int tat[n];       // Turnaround Time array
    int wt[n];        // Waiting Time array
    bool completed[n]; // Boolean array to track completed processes (True/False)

    // ----- INPUT SECTION -----
    for(int i = 0; i < n; i++) // Loop runs for each process
    {
        cout << "Enter Arrival Time and Burst Time for P" << i+1 << ": ";
        cin >> at[i] >> bt[i]; // Take arrival and burst time
        completed[i] = false;  // Initially mark all processes as not completed
    }

    int time = 0; // Current CPU time starts from 0
    int done = 0; // Count of completed processes

    while(done < n) // Continue until all processes are completed
    {
        int minBT = 9999; // Store minimum burst time
        int index = -1;   // Store index of selected process

        // Check all processes
        for(int i = 0; i < n; i++)
        {
            // Check if process has arrived AND not completed
            if(at[i] <= time && completed[i] == false)
            {
                // Check if burst time is smaller than current minimum
                if(bt[i] < minBT)
                {
                    minBT = bt[i];
                    index = i;
                }
            }
        }

        // If a valid process is found
        if(index != -1)
        {
            time = time + bt[index]; // Execute process fully
            ct[index] = time;        // Completion Time
            tat[index] = ct[index] - at[index]; // Turnaround Time
            wt[index] = tat[index] - bt[index]; // Waiting Time
            completed[index] = true; // Mark process completed
            done++;                  // Increase completed count
        }
        else
        {
            time++; // If no process arrived CPU stays idle
        }
    }

    // ----- OUTPUT SECTION -----
    cout << "\nPID\tAT\tBT\tCT\tTAT\tWT\n"; // Print table header
    for(int i = 0; i < n; i++) // Loop to display results
    {
        cout << i + 1 << "\t"
             << at[i] << "\t"
             << bt[i] << "\t"
             << ct[i] << "\t"
             << tat[i] << "\t"
             << wt[i] << "\n";
    }
    return 0; // End of program
}