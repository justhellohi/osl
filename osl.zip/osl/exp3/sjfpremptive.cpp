#include <iostream>
#include <limits>
using namespace std;

int main()
{
    int n;
    cout << "Enter number of processes: ";
    cin >> n;

    int at[n], bt[n], rt[n]; // arrival, burst, remaining time
    int ct[n], tat[n], wt[n]; // completion, turnaround, waiting time

    // Input arrival time and burst time
    for(int i = 0; i < n; i++)
    {
        cout << "Enter Arrival Time and Burst Time for P" << i+1 << ": ";
        cin >> at[i] >> bt[i];
        rt[i] = bt[i]; // remaining time initially equals burst time
    }

    int time = 0;
    int completed = 0;

    // SRTF Scheduling
    while(completed < n)
    {
        int minRT = INT_MAX;
        int index = -1;

        // Find process with minimum remaining time
        for(int i = 0; i < n; i++)
        {
            if(at[i] <= time && rt[i] > 0 && rt[i] < minRT)
            {
                minRT = rt[i];
                index = i;
            }
        }

        if(index != -1)
        {
            rt[index]--;
            time++;
            
            // If process finishes
            if(rt[index] == 0)
            {
                completed++;
                ct[index] = time;
                tat[index] = ct[index] - at[index];
                wt[index] = tat[index] - bt[index];
            }
        }
        else
        {
            time++; // CPU Idle
        }
    }

    cout << "\nPID\tAT\tBT\tCT\tTAT\tWT\n";
    for(int i = 0; i < n; i++) {
        cout << i + 1 << "\t"
             << at[i] << "\t"
             << bt[i] << "\t"
             << ct[i] << "\t"
             << tat[i] << "\t"
             << wt[i] << "\n";
    }
    return 0;
}