#include <iostream>
#include <fcntl.h>
#include <unistd.h>
#include <cstring>

using namespace std;

int main() {

    int fd;
    char buffer[100];

    fd = creat("demo.txt", 0777);

    if(fd < 0) {
        cout << "File creation failed";
        return 0;
    }

    cout << "File created successfully\n";

    const char *data = "Hello Operating System";

    write(fd, data, strlen(data));

    cout << "Data written successfully\n";

    close(fd);

    fd = open("demo.txt", O_RDONLY);

    int bytes = read(fd, buffer, sizeof(buffer));

    buffer[bytes] = '\0';

    cout << "Data from file: " << buffer << endl;

    close(fd);

    unlink("demo.txt");

    cout << "File deleted successfully\n";

    return 0;
}