#include <iostream>
#include <unistd.h>
#include <sys/stat.h>
#include <dirent.h>

using namespace std;

int main() {

    mkdir("MyDirectory", 0777);
    cout << "Directory created\n";

    chdir("MyDirectory");
    cout << "Changed directory\n";

    char path[100];

    getcwd(path, sizeof(path));

    cout << "Current Path: " << path << endl;

    chdir("..");

    DIR *dir;
    struct dirent *entry;

    dir = opendir(".");

    cout << "\nDirectory Contents:\n";

    while((entry = readdir(dir)) != NULL) {
        cout << entry->d_name << endl;
    }

    closedir(dir);

    rmdir("MyDirectory");

    cout << "Directory removed\n";

    return 0;
}