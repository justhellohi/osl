#include <iostream>
#include <unistd.h>
#include <sys/wait.h>

using namespace std;

int main() {

    pid_t pid;

    pid = fork();

    if(pid < 0) {
        cout << "Fork failed\n";
    }

    else if(pid == 0) {

        cout << "Child Process Running\n";

        cout << "Child PID: " << getpid() << endl;

        execl("/bin/ls", "ls", NULL);

        cout << "Execution failed\n";
    }

    else {

        wait(NULL);

        cout << "Parent Process Running\n";

        cout << "Parent PID: " << getpid() << endl;
    }

    return 0;
}