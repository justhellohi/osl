#include <iostream>
using namespace std;

int main()
{
    int n, m;

    // Input number of processes and resources
    cout << "Enter number of processes: ";
    cin >> n;

    cout << "Enter number of resources: ";
    cin >> m;

    // Declare matrices
    int alloc[n][m];
    int max[n][m];
    int need[n][m];
    int avail[m];

    // Input Allocation Matrix
    cout << "\nEnter Allocation Matrix:\n";
    for(int i = 0; i < n; i++)
    {
        for(int j = 0; j < m; j++)
        {
            cin >> alloc[i][j];
        }
    }

    // Input Max Matrix
    cout << "\nEnter Max Matrix:\n";
    for(int i = 0; i < n; i++)
    {
        for(int j = 0; j < m; j++)
        {
            cin >> max[i][j];
        }
    }

    // Input Available Resources
    cout << "\nEnter Available Resources:\n";
    for(int j = 0; j < m; j++)
    {
        cin >> avail[j];
    }

    // Calculate Need Matrix
    // Need = Max - Allocation
    for(int i = 0; i < n; i++)
    {
        for(int j = 0; j < m; j++)
        {
            need[i][j] = max[i][j] - alloc[i][j];
        }
    }

    // Finish array
    bool finish[n];

    for(int i = 0; i < n; i++)
    {
        finish[i] = false;
    }

    // Safe sequence array
    int safeSeq[n];

    // Work array
    int work[m];

    // Copy available resources into work
    for(int j = 0; j < m; j++)
    {
        work[j] = avail[j];
    }

    int count = 0;

    // Banker's Algorithm
    while(count < n)
    {
        bool found = false;

        for(int i = 0; i < n; i++)
        {
            // Check if process is unfinished
            if(finish[i] == false)
            {
                bool possible = true;

                // Check Need <= Work
                for(int j = 0; j < m; j++)
                {
                    if(need[i][j] > work[j])
                    {
                        possible = false;
                        break;
                    }
                }

                // If process can execute
                if(possible == true)
                {
                    // Release allocated resources
                    for(int j = 0; j < m; j++)
                    {
                        work[j] = work[j] + alloc[i][j];
                    }

                    // Add process to safe sequence
                    safeSeq[count] = i;
                    count++;

                    finish[i] = true;
                    found = true;
                }
            }
        }

        // If no process found
        if(found == false)
        {
            cout << "\nSystem is NOT in SAFE STATE\n";
            return 0;
        }
    }

    // Safe state
    cout << "\nSystem is in SAFE STATE\n";

    cout << "Safe Sequence: ";

    for(int i = 0; i < n; i++)
    {
        cout << "P" << safeSeq[i] << " ";
    }

    cout << endl;

    return 0;
}