#include <iostream>
using namespace std;

int main()
{
    int n, m;
    cout << "Enter number of processes: ";
    cin >> n;
    cout << "Enter number of resources: ";
    cin >> m;

    int alloc[n][m], max[n][m], need[n][m];
    int avail[m];
    string row;

    // Allocation Matrix
    cout << "\nEnter Allocation Matrix:\n";
    for(int i = 0; i < n; i++) {
        cin >> row; // e.g., 0102
        for(int j = 0; j < m; j++) {
            alloc[i][j] = row[j] - '0';
        }
    }

    // Max Matrix
    cout << "\nEnter Max Matrix:\n";
    for(int i = 0; i < n; i++) {
        cin >> row; // e.g., 7534
        for(int j = 0; j < m; j++) {
            max[i][j] = row[j] - '0';
        }
    }

    // Available Resources
    cout << "\nEnter Available Resources:\n";
    cin >> row;
    for(int j = 0; j < m; j++) {
        avail[j] = row[j] - '0';
    }

    // Need = Max - Allocation
    for(int i = 0; i < n; i++) {
        for(int j = 0; j < m; j++) {
            need[i][j] = max[i][j] - alloc[i][j];
        }
    }

    bool finish[n];
    for(int i = 0; i < n; i++) {
        finish[i] = false;
    }

    int safeSeq[n];
    int work[m];

    // Copy avail to work
    for(int i = 0; i < m; i++) {
        work[i] = avail[i];
    }

    int count = 0;
    // Banker's Algorithm
    while(count < n) {
        bool found = false;
        for(int i = 0; i < n; i++) {
            if(!finish[i]) {
                bool possible = true;
                for(int j = 0; j < m; j++) {
                    if(need[i][j] > work[j]) {
                        possible = false;
                        break;
                    }
                }
                if(possible) {
                    for(int j = 0; j < m; j++) {
                        work[j] += alloc[i][j];
                    }
                    safeSeq[count++] = i;
                    finish[i] = true;
                    found = true;
                }
            }
        }
        if(!found) {
            cout << "\nSystem is NOT in safe state";
            return 0;
        }
    }

    cout << "\nSystem is in SAFE STATE\n";
    cout << "Safe Sequence: ";
    for(int i = 0; i < n; i++) {
        cout << "P" << safeSeq[i] << " ";
    }
    cout << endl;

    return 0;
}